package Assignment;

public class Sever {
}
