package Assignment;

public class LightCycle {
}
