package Assignment;

public class LeaderBoard {
}
