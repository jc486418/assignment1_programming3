package Assignment;

public class Client {
}
