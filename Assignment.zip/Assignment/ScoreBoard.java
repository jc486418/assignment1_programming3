package Assignment;

public class ScoreBoard {
}
